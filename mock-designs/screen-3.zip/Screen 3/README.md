# Screen 3

This is a code bundle for Screen 3. It's based on default Vite project. The original design is available at https://app.flowstep.ai/file?activeFileId=ed917053-ec86-4192-a108-9d34533bf306.

## Running the code

Run `npm i` and `npm run setup` to install the dependencies.

Run `npm run dev` to start the development server.
